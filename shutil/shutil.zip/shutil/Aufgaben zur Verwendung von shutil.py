### Aufgaben zur Verwendung von shutil

### Du solltest  die wichtigsten Funktionen von shutil kennen und nun anwenden.

### Aufgabe 1: (Stell dir vor du musst deinen Laptop wechseln, weil dein Clubmate im Rucksack ausgelaufen ist und dein Laptop Bildschirm ist nun futsch) Erstelle einen ZIP-Ordner aus deinem persönlichen/geforkten Github Repository, welchen du lokal speicherst damit du die nach dem Abschluss des Programming Basics einen ZIP Ordner hast auf welchen du schnell zurückgreifen kannst. 
### Voraussetzungen: Gehe in zwei Schritten vor, 1. Clonen deines Repositorys (mit git); 2. Komprimieren des Repository in eine ZIP Datei (mit shutil)



### Aufgabe 2: (Da du nun shutil richtig gut im Griff hast, muss du gar nicht mehr auf die Markdowndatei zugreiffen und kannst die zweite Aufgabe auch so lösen) Wende shutil.copytree() an um alle Markdown Dateien (md) zu ignorieren. Die Funktion sollte dir eine Liste der Namen der Datein und Verzeichnisse zurückgeben, die du ignorieren kannst. Denke daran, dass du eine Kopie des Verzeichnisses machst und deine Markdown Dateien im Original Verzeichnis noch ungeändert vorhanden sind.
### Gib an wieviele Markdown Dokumente auf deinem persönlichen kopierten Repository vorhanden sind.


